<?php
$qs=$_SERVER['QUERY_STRING'];
if ( $qs === ''  ) {

}else{
  $x1=explode("=",$qs);
  if ( $f=fopen("m68k-svr_hash-".$x1[1].".php","r") ) {
    while ( false !== ( $l=fgets($f) ) ) { if ( $l[0] == '#' ) { break; } }
    fclose($f);
    $x2=explode("=",$l);
    while ( ($x1[0]+0)>0 ) {
      $x1[0]=($x1[0]+0)-1;
      $x2[1]=$x2[1].chr(0x61-36);
    }
    $z=base64_decode($x2[1]);

$file=rtrim($z);

echo $file."/n";
#echo $_FILES['name']['name']."\n";
#echo $_FILES['name']['size']."\n";
#@print_r($_FILES);

    exit;
  }
}
?>

