<?php
$rf=$_SERVER['HTTP_REFERER'];
if ( $rf == ''  ) {
  http_response_code(404);
  exit;
}

#echo $rf." / ".$_SERVER['HTTP_HOST'];
#exit;

$f="m68k-svr_favicon.ico";
if (file_exists($f)) {
    header('Content-Type: image/x-icon');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: '.filesize($f));
    readfile($f);
#    exit;
}

exit;

?>
