<?php
$qs=$_SERVER['QUERY_STRING'];
if ( $qs === ''  ) {
  exit;
}else{
  if ( is_nan($qs[0]) || $qs[1]!='=' ) { exit; }    
  $x1=explode("=",$qs);
  if ( $f=fopen("m68k-svr_hash-dir/m68k-svr_hash-".$x1[1].".php","r") ) {
    while ( false !== ( $l=fgets($f) ) ) { if ( $l[0] == '#' ) { break; } }
    fclose($f);
    $x2=explode("=",$l);
    while ( ($x1[0]+0)>0 ) {
      $x1[0]=($x1[0]+0)-1;
      $x2[1]=$x2[1].chr(0x61-36);
    }
    $z=base64_decode(str_replace('+','',$x2[1]));

    $f=rtrim($z);
    if (file_exists($f)) {
      header('Content-Description: File Transfer');
      header('Content-Type: application/octet-stream');
      header('Content-Disposition: attachment; filename="'.basename($f).'"');
      header('Expires: 0');
      header('Cache-Control: must-revalidate');
      header('Pragma: public');
      header('Content-Length: '.filesize($f));
      readfile($f);
      exit;
    }
  }
}
?>

