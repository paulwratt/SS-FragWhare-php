<?php include_once 'm68k-svr_no-cache.php'; ?><?php
$qs=$_SERVER['QUERY_STRING'];
if ( $qs === ''  ) {
  exit;
}else{
#echo "00";
#echo"qs='".$qs."'<br>\n";
  if ( is_nan($qs[0]) || !strpos($qs,'=') ) { exit; }
  $x1=explode("=",$qs);
  if ( is_nan($x1[0]) || is_nan($x1[1]) ) { exit; }
  if ( $f=fopen("m68k-svr_hash-dir/m68k-svr_hash-".$x1[3].".php","r") ) {
    while ( false !== ( $l=fgets($f) ) ) { if ( $l[0] == '#' ) { break; } }
    fclose($f);
    $x2=explode("=",$l);
    while ( ($x1[2]+0)>0 ) {
      $x1[2]=($x1[2]+0)-1;
      $x2[1]=$x2[1].chr(0x61-36);
    }
    $z=rtrim(base64_decode(str_replace('+','',$x2[1])));
#    $z=rtrim(base64_decode(str_replace('%2B','+',$x2[1])));    
#    echo "<font face=sans-serif><b>".$z."</b></font></br>";
#echo "file='".$z."'<br>\n";
#echo "01";

    # create file if not exists
    if ( !file_exists($z) ) {
      if ( ($x1[0]+0)!=0 || ($x1[1]+0)!=0 || $x1[4]!='' ) { exit; }
      if ( ($x1[0]+0)==0 && ($x1[1]+0)==0 && touch("$z") ) {
#echo "create<br>\n";
        echo 'ok';
      }
#echo " create '".$z."'\n";
      exit;
    }
#echo "02";

    # empty file if exists
    if ( ($x1[0]+0)==0 && ($x1[1]+0)==0 ) {
      if ( $f=fopen("$p/$z","w") ) {
        fclose($f);
#echo "empty<br>\n";
        echo 'ko';
      }
#echo " empty '".$z."'\n";
      exit;
    }
#echo "03";

    # check some stuff
    $line="";
    if ( isset($x1[5]) ) { $x1[4] .= "="; }
    if ( isset($x1[6]) ) { $x1[4] .= "="; }
#echo "'".$x1[4]."'";
    if ( strlen($x1[4]) > 0) { $line=base64_decode(str_replace('%2B','+',$x1[4])); }
#    $line=str_replace("%0D",'\\n',$line);
#    if ( strlen($x1[4]) > 0) { $line=base64_decode($x1[4]); }
#echo "line='".$line."'";
#echo "length of line=".strlen($x1[4]);
    if ( strlen($line) != ($x1[1]+0) ) { exit; }
    $totalLines = intval(exec("wc -l '$z'"));
#echo " lines in '".$z."': ".$totalLines."\n";
#echo "04";

    # insert line if exists
    if ( ($x1[0]+0) <= $totalLines && $x1[1][0]=='+' ) {
      if ( exec("tail -n +".($x1[0]+0)." '$p/$z' > '.tmp' && truncate -s $(head -n ".($x1[0]-1)." '$p/$z' | wc -c) '$p/$z' && echo '".$line." >> '$p/$z' && cat .tmp >> '$p/$z' && rm -f .tmp ;") ) {
#echo "insert<br>\n";
      echo "+";
      }
#echo " insert ".$x1[0].": '".$line."'\n";
      exit;
    }
#echo "05";

    # delete line if exists
    if ( ($x1[0]+0) <= $totalLines && $x1[1][0]=='-' ) {
      if ( exec("sed -i ".$x1[0]."d '$z'") ) {
#echo "delete<br>\n";
        echo "-";
      }
#echo " delete ".$x1[0].": '".$line."'\n";
      exit;
    }
#echo "06";

    # replace line if exists
    if ( ($x1[0]+0) <= $totalLines && ($x1[1]+0)>0 ) {
     if ( exec("tail -n +".($x1[0]+1)." '$p/$z' > '.tmp' && truncate -s $(head -n ".($x1[0]-1)." '$p/$z' | wc -c) '$p/$z' && echo '".$line." >> '$p/$z' && cat .tmp >> '$p/$z' && rm -f .tmp ;") ) {
#echo "replace<br>\n";
        echo "=";
      }
#echo " replace ".$x1[0].": '".$line."'\n";
      exit;
    }
#echo "07";

    # append line if not exists
#    if ( ($x1[0]+0) > $totalLines ) {
      if ( file_put_contents("$p/$z",$line,FILE_APPEND|LOCK_EX) ) {
#      if ( $f=fopen("$p/$z","a") ) {
#        fwrite($f,$line);
#        fflush($f);
#        fclose($f);
#echo "append<br>\n";
        echo ".";
      }
#echo " append ".$x1[0].": '".str_replace("\n",'',$line)."'\n";
      exit;
#    }
#echo "08";
  }
}
?>

