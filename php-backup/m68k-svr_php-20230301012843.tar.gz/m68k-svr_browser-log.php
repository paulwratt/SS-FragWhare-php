<?php
$t = date(DATE_W3C);
$p = $_SERVER['HOME'];
$h = $_SERVER['HTTP_HOST'];
$b = $_SERVER['HTTP_USER_AGENT'];
$i = $_SERVER['REMOTE_ADDR'];
$f = fopen($p."/m68k-svr_log-dir/browser-".$h."-log","a+");
fwrite($f,$t."#".$i."#".$b."\n");
fclose($f);
?>
