<html><?php include 'm68k-svr_browser-log.php'; ?>
<head>
<title>m68k build service</title>
</head>
<body>
<table border=0 cellpadding=0 cellspacing=0 align=center valign=center width=100% height=100%>
<tr valign=middle><td width=100% height=100% align=center><table><tr><td align=center><font face="sans-serif">

<b><u>m68k build server</u></b><br>
<?php echo $_SERVER['HTTP_HOST']; ?> Online<br>

</font></td></tr></table></td></tr>
</table>
</body>
</html>

