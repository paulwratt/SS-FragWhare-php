<?php include_once 'm68k-svr_no-cache.php'; ?><html>
<head>
<title>m68k build service - stats</title>
</head>
<body>
<table border=0 cellpadding=0 cellspacing=0 align=center valign=center width=100% height=100%>
<tr valign=middle><td width=100% height=100% align=center><table><tr><td align=center><font face="sans-serif">

<b><u>m68k build server</u></b><br>
<a href="m68k-svr_stats.php">stats</a> | <a href="m68k-svr_browsers.php">browsers</a> | <a href="m68k-svr_haxors.php">haxors</a> | <a href="m68k-svr_sshd.php">sshd</a> | <b>blocks</b><br>

<font size=-2><br><?php readfile("m68k-svr_stats-dir/total.ipv4"); ?> blocked : <?php readfile("m68k-svr_stats-dir/hourly.ipv4"); ?> in last hour : <?php readfile("m68k-svr_stats-dir/daily.ipv4"); ?> in last 24 hours<br><br></font>

<table border=1 cellpadding=5 c ellspacing=0 s tyle="border-collapse:collapse;">
<tr><th width=140>&nbsp;&nbsp;<font size=-2><?php readfile("m68k-svr_stats-dir/blocks.last"); ?></font>&nbsp;&nbsp;</th><th>&nbsp;&nbsp;<?php readfile("m68k-svr_stats-dir/blocks.ipv4"); ?> since last archive&nbsp;&nbsp;</th><th>date blocked</th></tr>
<?php
exec("cd ".$p."/m68k-svr_tools-dir; ./m68k-svr_update-hourly-sshd.sh");
if ( $dh=opendir("./m68k-svr_stats-dir/blocks/") ) {
  $fl=array();
  while ( false !== ( $lf=readdir($dh) ) ) {
    $lf=rtrim($lf);
    if ( $lf[0] == '.' ) { continue; }
#echo "$lf:";
    $c=file_get_contents($p."/m68k-svr_stats-dir/haxors/".$lf);
#echo "'$c':";
#echo strlen($c)."\n";
      if ( strpos($lf,'#')>0 ) {
 	$parts=explode(" ",$lf);
        $lf=str_replace('#','/',$parts[0]);
        $c=$parts[1];
      } else {
        if ( ($c+0) == 0 ) { $c='sshd'; }
      }      
    $fl[ (string)$lf ]=$c;
  }

  ksort($fl,SORT_NATURAL);
  foreach ( $fl as $key => $val ) {
    $c=file_get_contents("./b/ipv4/".$key);
    if ( !file_exists("./b/ipv4/".$key) ) { $c=exec("grep '".$key."' './l/monitor-ipv4.sshd' | cut -d \# -f 1 "); }
    # cron "redo"
    if ( strpos($c,":53:") ) { $c="<font color=#888888>".$c."</font>"; }
    echo "<tr><td>&nbsp;<a href=http://centralops.net/co/domaindossier.aspx?dom_whois=true&dom_dns=true&traceroute=true&net_whois=true&svc_scan=true&addr=".$key." target=_blank alt=DomainDossier title=DomainDossier>".$key."</a>&nbsp;</td><td align=right>&nbsp;<a href=http://isc.sans.edu/ipinfo.html?ip=".$key." target=_blank alt=InternetStormCenter title=InternetStormCenter>".$val."</a>&nbsp;</td><td><font size=-1>".$c."</font></td></tr>\n";

  }    
#  closedir($dh);

}

?>
</table>

&nbsp; &nbsp; <br>
<font size=-1>
haxors last updated<br>
<?php readfile("m68k-svr_stats-dir/haxors.updated"); ?><br>
runtime: <?php readfile("m68k-svr_stats-dir/haxors.time"); ?>s<br>
</font>

</font></td></tr></table></td></tr>
</table>
</body>
</html>


