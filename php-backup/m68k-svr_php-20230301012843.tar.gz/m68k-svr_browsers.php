<?php include_once 'm68k-svr_no-cache.php'; ?><html>
<head>
<title>m68k build service - stats</title>
</head>
<body>
<table border=0 cellpadding=0 cellspacing=0 align=center valign=center width=100% height=100%>
<tr valign=middle><td width=100% height=100% align=center><table><tr><td align=center><font face="sans-serif">

<b><u>m68k build server</u></b><br>
<a href="m68k-svr_stats.php">stats</a> | <b>browsers</b> | <a href="m68k-svr_haxors.php">haxors</a> | <a href="m68k-svr_sshd.php">sshd</a> | <a href="m68k-svr_blocks.php">blocks</a><br>

<font size=-2><br><?php readfile("m68k-svr_stats-dir/total.ipv4"); ?> blocked : <?php readfile("m68k-svr_stats-dir/hourly.ipv4"); ?> in last hour : <?php readfile("m68k-svr_stats-dir/daily.ipv4"); ?> in last 24 hours<br><br></font>

<table border=1 cellpadding=5 c ellspacing=0 s tyle="border-collapse:collapse;">
<tr><th>&nbsp;&nbsp;browsers&nbsp;&nbsp;</th><th>&nbsp;&nbsp;index&nbsp;&nbsp;</th></tr>
<?php

if ( $dh=opendir("./m68k-svr_stats-dir/browsers/") ) {
  $fl=array();
  while ( false !== ( $lf=readdir($dh) ) ) {
    if ( $lf[0] == '.' ) { continue; }
    $fl[]=$lf;
  }
  rsort($fl);
  $h='';
  while( NULL !== ($f=array_pop($fl)) ) {
    $l=explode('-',$f);
    if ( $l[0] != $h ) {
      $h=$l[0];
      echo "<tr><td align=right colspan=2><b>".$h."</b></td></tr>\n";
    }
    $c=file_get_contents("./m68k-svr_stats-dir/browsers/".$f);
    echo "<tr><td>".$l[1]."</td><td align=right>".$c."</td></tr>\n";
  }
#  closedir($dh);

}

?>
</table>

&nbsp; &nbsp; <br>
<font size=-1>
browsers last updated<br>
<?php readfile("m68k-svr_stats-dir/browsers.updated"); ?><br>
runtime: <?php readfile("m68k-svr_stats-dir/browsers.time"); ?>s<br>
</font>



</font></td></tr></table></td></tr>
</table>
</body>
</html>

