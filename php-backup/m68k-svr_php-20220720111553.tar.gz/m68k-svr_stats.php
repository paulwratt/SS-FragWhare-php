<?php include_once 'm68k-svr_no-cache.php'; ?><html>
<head>
<title>m68k build service - stats</title>
</head>
<body>
<table border=0 cellpadding=0 cellspacing=0 align=center valign=center width=100% height=100%>
<tr valign=middle><td width=100% height=100% align=center><table><tr><td align=center><font face="sans-serif">

<b><u>m68k build server</u></b><br>
<b>stats</b> | <a href="m68k-svr_browsers.php">browsers</a> | <a href="m68k-svr_haxors.php">haxors</a> | <a href="m68k-svr_sshd.php">sshd</a> | <a href="m68k-svr_blocks.php">blocks</a><br>

<font size=-2><br><?php readfile("m68k-svr_stats-dir/total.ipv4"); ?> blocked : <?php readfile("m68k-svr_stats-dir/hourly.ipv4"); ?> in last hour : <?php readfile("m68k-svr_stats-dir/daily.ipv4"); ?> in last 24 hours<br><br></font>

<table border=1 cellpadding=5 c ellspacing=0 s tyle="border-collapse:collapse;">
<tr><th>&nbsp;&nbsp;visitors&nbsp;&nbsp;</th><th>&nbsp;&nbsp;index&nbsp;&nbsp;</th></tr>
<tr><td><a href="m68k-svr_log-list.php?log=45.79.59.32">45.79.59.32</a></td><td align=right><?php readfile("m68k-svr_stats-dir/45.79.59.32.visits"); ?></td><tr>
<tr><td>visitors</td><td align=right><?php readfile("m68k-svr_stats-dir/45.79.59.32.unique"); ?></td></tr>
<tr><td><a href="m68k-svr_log-list.php?log=45.79.59.32:80">45.79.59.32:80</a></td><td align=right><?php readfile("m68k-svr_stats-dir/45.79.59.32:80.visits"); ?></td></tr>
<tr><td>visitors</td><td align=right><?php readfile("m68k-svr_stats-dir/45.79.59.32:80.unique"); ?></td></tr>
<tr><td><a href="m68k-svr_log-list.php?log=atarist.at">atarist.at</a></td><td align=right><?php readfile("m68k-svr_stats-dir/atarist.at.visits"); ?></td></tr>
<tr><td>visitors</td><td align=right><?php readfile("m68k-svr_stats-dir/atarist.at.unique"); ?></td></tr>
<tr><td><a href="m68k-svr_log-list.php?log=isource.net.nz">isource.net.nz</a></td><td align=right><?php readfile("m68k-svr_stats-dir/isource.net.nz.visits"); ?></td></tr>
<tr><td>visitors</td><td align=right><?php readfile("m68k-svr_stats-dir/isource.net.nz.unique"); ?></td></tr>
<tr><td><a href="m68k-svr_log-list.php?log=li1158-32.members.linode.com">li1158</a></td><td align=right><?php readfile("m68k-svr_stats-dir/li1158.visits"); ?></td></tr>
<tr><td>visitors</td><td align=right><?php readfile("m68k-svr_stats-dir/li1158.unique"); ?></td></tr>
<tr><td><a href="m68k-svr_log-list.php?log=">noaddr</a></td><td align=right><?php readfile("m68k-svr_stats-dir/noaddr.visits"); ?></td></tr>
<tr><td>visitors</td><td align=right><?php readfile("m68k-svr_stats-dir/noaddr.unique"); ?></td></tr>
<tr><td><a href="./m68k-svr_log-dir/nginx-errors.log">errors</a></td><td align=right><?php readfile("m68k-svr_stats-dir/errors.visits"); ?></td></tr>
<tr><td><a href="./m68k-svr_stats-dir/errors/">visitors</a></td><td align=right><?php readfile("m68k-svr_stats-dir/errors.unique"); ?></td></tr>
<tr><td><a href="./m68k-svr_log-dir/haxors-access.log">haxors</a></td><td align=right><?php readfile("m68k-svr_stats-dir/haxors.visits"); ?></td></tr>
<tr><td><a href="./m68k-svr_stats-dir/haxors/">visitors</a></td><td align=right><?php readfile("m68k-svr_stats-dir/haxors.unique"); ?></td></tr>
<tr><td><a href="./m68k-svr_log-dir/">total</a></td><td align=right><?php readfile("m68k-svr_stats-dir/total.visits"); ?></td></tr>
<tr><td><a href="./m68k-svr_stats-dir/">visitors</a></td><td align=right><?php readfile("m68k-svr_stats-dir/total.unique"); ?></td></tr>
</table>

&nbsp; &nbsp; <br>

<font size=-1>
logs last updated<br>
<?php readfile("m68k-svr_stats-dir/last.updated"); ?><br>
runtime: <?php readfile("m68k-svr_stats-dir/run.time"); ?>s<br>
</font>

</font></td></tr></table></td></tr>
</table>
</body>
</html>

