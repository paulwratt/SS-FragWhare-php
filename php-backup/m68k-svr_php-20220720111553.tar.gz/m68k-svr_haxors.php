<?php include_once 'm68k-svr_no-cache.php'; ?><html>
<head>
<title>m68k build service - stats</title>
</head>
<body>
<table border=0 cellpadding=0 cellspacing=0 align=center valign=center width=100% height=100%>
<tr valign=middle><td width=100% height=100% align=center><table><tr><td align=center><font face="sans-serif">

<b><u>m68k build server</u></b><br>
<a href="m68k-svr_stats.php">stats</a> | <a href="m68k-svr_browsers.php">browsers</a> | <b>haxors</b> | <a href="m68k-svr_sshd.php">sshd</a> | <a href="m68k-svr_blocks.php">blocks</a><br>

<font size=-2><br><?php readfile("m68k-svr_stats-dir/total.ipv4"); ?> blocked : <?php readfile("m68k-svr_stats-dir/hourly.ipv4"); ?> in last hour : <?php readfile("m68k-svr_stats-dir/daily.ipv4"); ?> in last 24 hours<br><br></font>

<table border=1 cellpadding=5 c ellspacing=0 s tyle="border-collapse:collapse;">
<tr><th>&nbsp;&nbsp;<a href="m68k-svr_log-dir/haxors-access.log">haxors log</a>&nbsp;&nbsp;</th><th>&nbsp;&nbsp;<?php readfile("m68k-svr_stats-dir/haxors.unique"); ?>/<?php readfile("m68k-svr_stats-dir/haxors.visits"); ?>&nbsp;&nbsp;</th></tr>
<?php

if ( $dh=opendir("./m68k-svr_stats-dir/haxors/") ) {
  $fl=array();
  while ( false !== ( $lf=readdir($dh) ) ) {
    if ( $lf[0] == '.' ) { continue; }
    $c=file_get_contents("./m68k-svr_stats-dir/haxors/".$lf);
    $fl[ (string)$lf ]=$c;
  }
#  asort($fl);
  natsort($fl);
#  arsort($fl);
  $rl=array_reverse($fl, true);
  $sl=array();
  $ca=array();

  foreach ( $rl as $key => $val ) {
    if ( !is_array($sl[$val]) ) { $sl[$val]=array(); $ca[]=$val; }
    $sl[$val][]=(string) $key;
  }

  $val=0;
  foreach ( $sl as $na ) {
    natsort($na);

    foreach ( $na as $kk => $key ) {
    echo "<tr><td>&nbsp;<a href=http://centralops.net/co/domaindossier.aspx?dom_whois=true&dom_dns=true&traceroute=true&net_whois=true&svc_scan=true&addr=".$key." target=_blank alt=DomainDossier title=DomainDossier>".$key."</a>&nbsp;</td><td align=right>&nbsp;<a href=http://isc.sans.edu/ipinfo.html?ip=".$key." target=_blank alt=InternetStormCenter title=InternetStormCenter>".$ca[$val]."</a>&nbsp;</td></tr>\n";
    }
    $val++;

  }    
#  closedir($dh);

}

?>
</table>

&nbsp; &nbsp; <br>
<font size=-1>
haxors last updated<br>
<?php readfile("m68k-svr_stats-dir/haxors.updated"); ?><br>
runtime: <?php readfile("m68k-svr_stats-dir/haxors.time"); ?>s<br>
</font>

</font></td></tr></table></td></tr>
</table>
</body>
</html>

