<?php include_once 'm68k-svr_no-cache.php'; ?><html>
<head>
<title>m68k build service - logs</title>
</head>
<body>
<table border=0 cellpadding=0 cellspacing=0 align=center valign=center width=100% height=100%>
<tr valign=middle><td width=100% height=100% align=center><table><tr><td align=center><font face="sans-serif">

<b>m68k build server</b><br>
log list<br>
&nbsp;&nbsp;<br>

<table border=1 cellpadding=5>
<?php
#ini_set('display_errors', 1);
#ini_set('display_startup_errors', 1);
#error_reporting(E_ALL);

function getQueryParameter ($strParam) {
  $aParamList = explode('&', $_SERVER['QUERY_STRING']);
  $i = 0;
  while ($i < count($aParamList)) {
    $aParam = explode('=', $aParamList[$i]);
    if ($strParam == $aParam[0]) {
      return $aParam[1];
    }
  }
  return "";
}

#$qs=(isset($_SERVER['QUERY_STRING']))?$_SERVER['QUERY_STRING']:'';
$qs=$_SERVER['QUERY_STRING'];
#echo $qs."<br>\n";
#if (isset($_GET['log']) { $log=$_GET['log']; } else { $log=''; }
#$log=(isset($_GET['log']) ? $_GET['log'] : '';
#$log="atarist.at";
#$log=(isset($_REQUEST['log']) ? $_REQUEST['log'] : '' ;
$log=($qs=='') ? '' : getQueryParameter("log");
if ( $log == '' && $qs == '' ) {
  if ( $dh=opendir("./m68k-svr_log-dir/") ) {
    echo "<tr><th><u>available:</u></th></tr>\n";
    while ( false !== ( $lf=readdir($dh) ) ) {
#      if ( $lf[0] == '.' ) { continue; }
      if ( $lf[0] != 'b' ) { continue; }
      $l=explode('-',$lf); $n=$l[1]; $i=$n;
      if ( $n == '' ) { $n="noaddr"; }
      if ( $n == 'li1158' ) { $i="li1158-32.members.linode.com"; }
      echo "<tr><td>&nbsp;&nbsp;<a href=\"m68k-svr_log-list.php?log=".$i."\">".$n."</a></td></tr>\n";

    }
#    closedir(dh$);
  }
} else {
  echo "<tr><th nowrap><u>visited: ".$log."</u></th><th><u>from</u></th><th><u>with</u></th></tr>\n";
  if ( $fh=fopen("./m68k-svr_log-dir/browser-".$log."-log","r") ) {
    while ( false !== ( $ln=fgets($fh) ) ) {
      $l=explode('#',$ln);
      $t=str_replace('T',' ',$l[0]);
      $b=str_replace('<','&lt;',$l[2]);
      echo "<tr><td>".$t."</td><td>&nbsp;&nbsp;<a href=\"http://centralops.net/co/domaindossier.aspx?addr=".$l[1]."\" target=\"_new\">".$l[1]."</a>&nbsp;&nbsp;</td><td no wrap>".$b."</td></tr>\n";
    }
    fclose($fh);
  }
}
?>
</table>

</font></td></tr></table></td></tr>
</table>
</body>
</html>

